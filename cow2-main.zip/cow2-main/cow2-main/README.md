# INFORMATION
This Update Tools cowCrack. (Bruteforce Facebook)
# COMMAND INSTALL
```BASH
$ pkg install python
$ pkg install git
$ pip install requests bs4
$ git clone https://github.com/Zaa077/z7
$ cd x7
$ python run.py
```
# THANKS TO :
```BASH
- ./X.Idenity
- Zaa Betmenn
- FRIENDS - FRIENDS.
```
